extends Control

# =========================================================
# ENUMS
# =========================================================

enum ShapeType { DIAMOND, CIRCLE, PILL }
enum TextureType { EMPTY, STRIPED, FILLED }
enum ColorType { GREEN, RED, PURPLE }

# =========================================================
# CARD MODEL
# =========================================================

class SetCard:
	var shape
	var texture
	var color
	var count

	func _init(s, t, c, n):
		shape = s
		texture = t
		color = c
		count = n

# =========================================================
# GAME STATE
# =========================================================

var deck: Array = []
var table: Array = []
var selected: Array = []

var start_time := 0
var game_over := false

# =========================================================
# UI ROOTS (CREATED IN CODE)
# =========================================================

var menu_vbox
var root_vbox

var top_bar
var grid
var status_label
var timer_label
var deck_label
var restart_button
var hint_button 

# =========================================================
# READY
# =========================================================

func _ready():
	get_viewport().content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
	get_viewport().content_scale_aspect = Window.CONTENT_SCALE_ASPECT_KEEP

	build_ui()

# =========================================================
# UI CREATION (NO SCENE FILES)
# =========================================================

func build_ui():

	# ---------------- APP BACKGROUND ----------------
	RenderingServer.set_default_clear_color(Color("1a1a1a"))

	# ---------------- ROOT MARGIN ----------------
	var screen_margin = MarginContainer.new()
	
	# 1. ALWAYS add the child to the tree first before changing layout
	add_child(screen_margin)
	
	# 2. THE NUCLEAR OPTION: Explicitly set the width and height to match the window
	screen_margin.size = get_viewport_rect().size
	
	# 3. Ensure it dynamically resizes if the window ever changes
	get_viewport().size_changed.connect(func():
		if is_instance_valid(screen_margin):
			screen_margin.size = get_viewport_rect().size
	)
	
	screen_margin.add_theme_constant_override("margin_left", 18)
	screen_margin.add_theme_constant_override("margin_right", 18)
	screen_margin.add_theme_constant_override("margin_top", 18)
	screen_margin.add_theme_constant_override("margin_bottom", 18)

	# =========================================================
	# MAIN MENU UI
	# =========================================================

	menu_vbox = VBoxContainer.new()
	menu_vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	menu_vbox.add_theme_constant_override("separation", 60)
	screen_margin.add_child(menu_vbox)
	
	menu_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	menu_vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL

	var title_label = Label.new()
	title_label.text = "SET"
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title_label.add_theme_font_size_override("font_size", 80)
	menu_vbox.add_child(title_label)

	var play_button = Button.new()
	play_button.text = "Play Game"
	play_button.custom_minimum_size = Vector2(240, 80)
	play_button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	play_button.add_theme_font_size_override("font_size", 32)

	var play_style = StyleBoxFlat.new()
	play_style.bg_color = Color("2a2a2a")
	play_style.corner_radius_top_left = 16
	play_style.corner_radius_top_right = 16
	play_style.corner_radius_bottom_left = 16
	play_style.corner_radius_bottom_right = 16

	play_button.add_theme_stylebox_override("normal", play_style)
	play_button.pressed.connect(on_play_pressed)
	menu_vbox.add_child(play_button)

	# =========================================================
	# GAME UI ROOT
	# =========================================================

	root_vbox = VBoxContainer.new()
	root_vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	root_vbox.add_theme_constant_override("separation", 14)
	screen_margin.add_child(root_vbox)
	
	root_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root_vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL

	# Hide the game board initially
	root_vbox.hide()

	# =========================================================
	# TOP BAR
	# =========================================================

	top_bar = HBoxContainer.new()
	top_bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root_vbox.add_child(top_bar)

	timer_label = Label.new()
	deck_label = Label.new()

	timer_label.text = "00:00"
	deck_label.text = "Deck: 81"

	timer_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	deck_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT

	timer_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL

	timer_label.add_theme_font_size_override("font_size", 22)
	deck_label.add_theme_font_size_override("font_size", 22)

	timer_label.modulate = Color.WHITE
	deck_label.modulate = Color.WHITE

	top_bar.add_child(timer_label)
	top_bar.add_child(deck_label)

	# =========================================================
	# STATUS LABEL
	# =========================================================

	status_label = Label.new()
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status_label.add_theme_font_size_override("font_size", 20)
	status_label.modulate = Color.WHITE
	root_vbox.add_child(status_label)

	# =========================================================
	# CARD GRID
	# =========================================================

	grid = GridContainer.new()
	grid.columns = 3
	grid.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)

	root_vbox.add_child(grid)

	# =========================================================
	# BOTTOM BUTTONS (MENU, HINT, RESTART)
	# =========================================================

	var bottom_buttons = HBoxContainer.new()
	bottom_buttons.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bottom_buttons.add_theme_constant_override("separation", 14)
	root_vbox.add_child(bottom_buttons)

	var btn_style = StyleBoxFlat.new()
	btn_style.bg_color = Color("2a2a2a")
	btn_style.corner_radius_top_left = 16
	btn_style.corner_radius_top_right = 16
	btn_style.corner_radius_bottom_left = 16
	btn_style.corner_radius_bottom_right = 16

	# Main Menu Button
	var menu_button = Button.new()
	menu_button.text = "Menu"
	menu_button.custom_minimum_size = Vector2(0, 56)
	menu_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	menu_button.flat = true
	menu_button.add_theme_font_size_override("font_size", 22)
	menu_button.add_theme_stylebox_override("normal", btn_style)
	menu_button.modulate = Color.WHITE
	menu_button.pressed.connect(on_menu_pressed)
	bottom_buttons.add_child(menu_button)
	
	# Hint Button
	hint_button = Button.new()
	hint_button.text = "Hint"
	hint_button.custom_minimum_size = Vector2(0, 56)
	hint_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hint_button.flat = true
	hint_button.add_theme_font_size_override("font_size", 22)
	hint_button.add_theme_stylebox_override("normal", btn_style)
	hint_button.modulate = Color.WHITE
	hint_button.pressed.connect(on_hint_pressed)
	bottom_buttons.add_child(hint_button)

	# Restart Button
	restart_button = Button.new()
	restart_button.text = "Restart"
	restart_button.custom_minimum_size = Vector2(0, 56)
	restart_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	restart_button.flat = true
	restart_button.add_theme_font_size_override("font_size", 22)
	restart_button.add_theme_stylebox_override("normal", btn_style)
	restart_button.modulate = Color.WHITE
	restart_button.pressed.connect(start_game)
	bottom_buttons.add_child(restart_button)

# =========================================================
# STATE TRANSITIONS
# =========================================================

func on_play_pressed():
	menu_vbox.hide()
	root_vbox.show()
	start_game()

func on_menu_pressed():
	root_vbox.hide()
	menu_vbox.show()
	game_over = true # Stop the timer

# =========================================================
# GAME START
# =========================================================

func start_game():

	deck.clear()
	table.clear()
	selected.clear()
	status_label.text = ""

	game_over = false
	start_time = Time.get_ticks_msec()

	build_deck()
	deck.shuffle()

	clear_grid()
	deal_solvable_board(9)

	update_ui()

# =========================================================
# DECK
# =========================================================

func build_deck():
	for s in ShapeType.values():
		for t in TextureType.values():
			for c in ColorType.values():
				for n in range(3): 
					deck.append(SetCard.new(s, t, c, n))

# =========================================================
# PNG
# =========================================================

func get_png_path(card: SetCard) -> String:
	var shapes = ["diamond", "circle", "pill"]
	var textures = ["empty", "striped", "filled"]
	var colors = ["green", "red", "purple"]

	return "res://assets/png/%s_%s_%s.png" % [
		shapes[card.shape],
		textures[card.texture],
		colors[card.color]
	]

# =========================================================
# DEAL
# =========================================================

func deal(count):
	for i in range(count):
		if deck.is_empty():
			return

		var card = deck.pop_back()
		table.append(card)
		add_card(card)

# =========================================================
# CARD UI (SELF CONTAINED)
# =========================================================

func add_card(card) -> Control:

	var btn = PanelContainer.new()
	btn.custom_minimum_size = Vector2(118, 215)
	
	btn.pivot_offset = btn.custom_minimum_size / 2.0

	var style = StyleBoxFlat.new()
	style.bg_color = Color.BLACK
	style.border_color = Color.WHITE
	style.border_width_left = 2
	style.border_width_right = 2
	style.border_width_top = 2
	style.border_width_bottom = 2
	style.corner_radius_top_left = 18
	style.corner_radius_top_right = 18
	style.corner_radius_bottom_left = 18
	style.corner_radius_bottom_right = 18

	btn.add_theme_stylebox_override("panel", style)

	var margin = MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 10)
	margin.add_theme_constant_override("margin_right", 10)
	margin.add_theme_constant_override("margin_top", 10)
	margin.add_theme_constant_override("margin_bottom", 10)
	btn.add_child(margin)

	var vbox = VBoxContainer.new()
	vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	vbox.add_theme_constant_override("separation", 10)
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin.add_child(vbox)

	var click = Button.new()
	click.flat = true
	click.anchor_right = 1
	click.anchor_bottom = 1
	click.mouse_filter = Control.MOUSE_FILTER_STOP
	btn.add_child(click)

	var path = get_png_path(card)
	var tex = load(path)

	if tex == null:
		push_error("FAILED TO LOAD: " + path)
		return null

	for i in range(card.count + 1):
		var img = TextureRect.new()
		img.texture = tex
		img.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		img.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		img.custom_minimum_size = Vector2(54, 54)
		
		img.texture_filter = Control.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS

		img.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		img.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		vbox.add_child(img)

	click.pressed.connect(on_card_pressed.bind(btn, card))

	grid.add_child(btn)
	return btn
	
# =========================================================
# CARD PRESS
# =========================================================

func on_card_pressed(button, card):

	if game_over:
		return

	if button in selected:
		selected.erase(button)
		button.scale = Vector2.ONE
	else:
		if selected.size() >= 3:
			return

		selected.append(button)
		button.scale = Vector2(1.05, 1.05)

	if selected.size() == 3:
		check_set()

# =========================================================
# SET LOGIC
# =========================================================

func check_set():

	var cards = []

	for b in selected:
		var idx = grid.get_children().find(b)
		cards.append(table[idx])

	if is_set(cards):
		status_label.text = "SET ✓"
		remove_cards() 
	else:
		status_label.text = "NOT SET ✗"
		
		for b in selected:
			b.modulate = Color.WHITE
			b.scale = Vector2.ONE 
			
		selected.clear()

# =========================================================
# VALIDATION
# =========================================================

func is_set(cards):

	return check(cards[0].shape, cards[1].shape, cards[2].shape) \
	and check(cards[0].texture, cards[1].texture, cards[2].texture) \
	and check(cards[0].color, cards[1].color, cards[2].color) \
	and check(cards[0].count, cards[1].count, cards[2].count)

func check(a, b, c):
	return (a == b and b == c) or (a != b and a != c and b != c)

# =========================================================
# REMOVE CARDS
# =========================================================

func remove_cards():

	var to_remove_indices = []

	for b in selected:
		to_remove_indices.append(grid.get_children().find(b))

	to_remove_indices.sort()
	to_remove_indices.reverse()

	for i in to_remove_indices:
		var old_btn = grid.get_child(i)
		grid.remove_child(old_btn) 
		old_btn.queue_free()

		if deck.size() > 0:
			var new_card = deck.pop_back()
			table[i] = new_card
			var new_btn = add_card(new_card) 
			grid.move_child(new_btn, i)
		else:
			table.remove_at(i)

	selected.clear()
	update_ui() 
	check_game_over() 

# =========================================================
# GAME OVER LOGIC
# =========================================================

func check_game_over():
	if find_set_on_table().size() == 0:
		game_over = true
		
		for c in grid.get_children():
			c.modulate = Color(0.5, 0.5, 0.5) 
			
		if table.size() == 0:
			status_label.text = "PERFECT CLEAR! YOU WIN!"
		else:
			status_label.text = "NO MORE SETS. GAME OVER!"

# =========================================================
# UI UPDATE
# =========================================================

func update_ui():
	deck_label.text = "Deck: %d" % deck.size()

# =========================================================
# CLEAR GRID
# =========================================================

func clear_grid():
	for c in grid.get_children():
		c.queue_free()

# =========================================================
# TIMER
# =========================================================

func _process(_delta):
	if game_over:
		return

	var t = (Time.get_ticks_msec() - start_time) / 1000

	timer_label.text = "%02d:%02d" % [
		int(t / 60),
		int(t) % 60
	]

# =========================================================
# SOLVABLE BOARD GENERATOR
# =========================================================

func deal_solvable_board(size := 9):

	clear_grid()
	table.clear()

	var board = []

	var set_triplet = generate_valid_set()
	board.append_array(set_triplet)

	var remaining = deck.duplicate()

	for c in set_triplet:
		remaining.erase(c)

	remaining.shuffle()

	while board.size() < size and remaining.size() > 0:
		board.append(remaining.pop_back())

	board.shuffle()
	table = board

	for card in table:
		add_card(card)

# =========================================================
# VALID SET GENERATOR
# =========================================================

func generate_valid_set() -> Array:
	var a = deck[randi() % deck.size()]
	var b = deck[randi() % deck.size()]

	var c = compute_third_card(a, b)

	if c == null or c == a or c == b:
		return generate_valid_set()

	return [a, b, c]

# =========================================================
# THIRD CARD CALCULATOR
# =========================================================

func compute_third_card(a: SetCard, b: SetCard):
	var c = SetCard.new(0, 0, 0, 0)

	c.shape = third_value(a.shape, b.shape)
	c.texture = third_value(a.texture, b.texture)
	c.color = third_value(a.color, b.color)
	c.count = third_value(a.count, b.count)

	for card in deck:
		if same_card(card, c):
			return card

	return null

# =========================================================
# SET LOGIC HELPER
# =========================================================

func third_value(x, y):
	if x == y:
		return x
	return 3 - (x + y)

# =========================================================
# CARD COMPARISON
# =========================================================

func same_card(a: SetCard, b: SetCard) -> bool:
	return a.shape == b.shape \
	and a.texture == b.texture \
	and a.color == b.color \
	and a.count == b.count

# =========================================================
# HINT LOGIC
# =========================================================

func on_hint_pressed():
	if game_over:
		return

	for b in selected:
		b.modulate = Color.WHITE
		b.scale = Vector2.ONE
	selected.clear()

	var valid_set_indices = find_set_on_table()

	if valid_set_indices.size() == 3:
		status_label.text = "Hint: Find the 3rd card!"
		
		# NEW: Shuffle the indices so it doesn't always highlight the exact same 2 cards
		valid_set_indices.shuffle()
		
		# NEW: Loop only twice (index 0 and 1) instead of 3 times
		for i in range(2):
			var idx = valid_set_indices[i]
			var btn = grid.get_child(idx)
			btn.modulate = Color("ffd700") 
	else:
		status_label.text = "No SETs currently possible!"

func find_set_on_table() -> Array:
	var n = table.size()
	
	for i in range(n - 2):
		for j in range(i + 1, n - 1):
			for k in range(j + 1, n):
				if is_set([table[i], table[j], table[k]]):
					return [i, j, k] 
					
	return []
